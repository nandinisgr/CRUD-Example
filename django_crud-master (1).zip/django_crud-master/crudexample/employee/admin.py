from django.contrib import admin
from employee.models import *

# Register your models here.
admin.site.register(Employee)
