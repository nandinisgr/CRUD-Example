from django.contrib import admin
from onlineapp.models import *

admin.site.register(StudentDetails)
admin.site.register(AdminDetails)
admin.site.register(Questions)

